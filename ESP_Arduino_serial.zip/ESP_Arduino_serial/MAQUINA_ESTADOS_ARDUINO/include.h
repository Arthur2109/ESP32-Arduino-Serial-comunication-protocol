#ifndef _INCLUDE_H_
#define _INCLUDE_H_

#include <Arduino.h>

//#include <WiFi.h>
#define LR 8
#define LV 9











#endif
