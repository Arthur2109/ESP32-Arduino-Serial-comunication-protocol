#include "main.h"

Ser S;
int l_mill;
void FSM::FSM_Principal(int estado_1){
  if(estado_1 == inicio){
    
    S.init();
    S.set_ESP_S(0);
    
    digitalWrite(LR, HIGH);
    digitalWrite(LV, LOW);
    //l_mill = millis();
    S.print_c("ESP_STATE");
    while(S.get_ESP_S() != 1){
      
      S.leerserial();
    }
    digitalWrite(LV, HIGH);
    digitalWrite(LR, LOW);
    delay(500);
    //Led verde
    //S.print_c("ESP OK"); //imprimir en otro serial de debug
    estado = opera;
    delay(2000);
  }else if(estado_1 == conf){


    
  }else if(estado_1 == opera){

    
    S.set_ESP_T(0);
    
    digitalWrite(LR, HIGH);
    digitalWrite(LV, LOW);
    //l_mill = millis();
    S.print_c("T1");
    while(S.get_ESP_T() != 1){
      
      S.leerserial();
    }
    digitalWrite(LV, HIGH);
    digitalWrite(LR, LOW);
    delay(500);
    
    
  }
}

void FSM::Init(){



  
}

int FSM::get_state(){

  return estado;
  
}
